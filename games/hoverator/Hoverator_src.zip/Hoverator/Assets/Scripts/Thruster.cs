﻿using UnityEngine;
using System.Collections;

public class Thruster : MonoBehaviour {

    public float thrusterDistance;
    public float thrusterStrength;
    public Transform[] thrusters;

    /*
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    */

    void FixedUpdate()
    {
        Vector3 downForce;
        float distancePercentage;
        RaycastHit hit;

        for (int i = 0; i < thrusters.Length; i++)
        {
            if (Physics.Raycast(thrusters[i].position, thrusters[i].up * -1, out hit, thrusterDistance))
            {
                distancePercentage = 1 - (hit.distance / thrusterDistance);
                downForce = thrusters[i].up * thrusterStrength * distancePercentage;
                downForce *= Time.deltaTime * rigidbody.mass;

                rigidbody.AddForceAtPosition(downForce, thrusters[i].position);
            }
        }
    }
}
