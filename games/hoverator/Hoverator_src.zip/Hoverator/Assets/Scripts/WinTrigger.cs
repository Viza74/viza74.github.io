﻿using UnityEngine;
using System.Collections;

public class WinTrigger : MonoBehaviour {

    void OnTriggerEnter(Collider coll)
    {
        if (coll.gameObject.tag=="Player")
        {
            Game.instance.Win();
            gameObject.SetActive(false);
        }
        

        
    }
}
