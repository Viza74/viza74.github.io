﻿using UnityEngine;
using System.Collections;

public class Bullet : MonoBehaviour {

    public float speed;
    public int   damage;

    public GameObject sparks;

    float timeLeft = 3;
    /*
	// Use this for initialization
	void Start () {
        
	}
	*/
	// Update is called once per frame
	void Update () {
        timeLeft -= Time.deltaTime;
        if (timeLeft<=0)
        {
            Destroy(gameObject);
            return;
        }

        transform.Translate(0, 0, speed * Time.deltaTime);
	}
    
    void FixedUpdate()
    {

    }
    
    void OnCollisionEnter(Collision coll)
    {
        //Debug.Log("Bullet collided with "+coll.transform.name);
        GameObject psys = (Instantiate(sparks, coll.contacts[0].point, Quaternion.LookRotation(coll.contacts[0].normal)) as GameObject);
        psys.transform.parent = Game.instance.entityParent;
        Destroy(psys, 1);
        //Instantiate(sparks, coll.contacts[0].point, Quaternion.Euler(coll.contacts[0].normal));
        Destroy(gameObject);    
    }
    
}
