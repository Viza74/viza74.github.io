﻿using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {

    private static Game _instance;

    public static Game instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = GameObject.FindObjectOfType<Game>();

                // For persistent singleton
                //Tell unity not to destroy this object when loading a new scene!
                //DontDestroyOnLoad(_instance.gameObject);
            }

            return _instance;
        }
    }

    [HideInInspector]
    public Transform player;

    [HideInInspector]
    public EnemyZone[] zones;

    public Transform entityParent;
    public SpriteRenderer gameOverSprite;
    public SpriteRenderer winSprite;

    public GUIText timeText;
    float levelTime = 0;

    void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        zones = GameObject.FindObjectsOfType<EnemyZone>();
        Enemy[] enemies = GameObject.FindObjectsOfType<Enemy>();
        
        for (int i = 0; i < enemies.Length; i++)
        {
            for (int o = 0; o < zones.Length; o++)
            {

                if (zones[o].collider.bounds.Intersects(enemies[i].myBounds))
                //if (zones[o].collider.bounds.Intersects(enemies[i].collider.bounds))
                {
                    enemies[i].myZone = zones[o];
                    zones[o].enemies.Add(enemies[i].gameObject);
                }
                
            }
        }

        gameOverSprite.enabled = false;
        winSprite.enabled = false;
    }

	// Use this for initialization
	void Start () {
        //Screen.lockCursor = true;
        for (int o = 0; o < zones.Length; o++)
        {

            if (zones[o].collider.bounds.Intersects(player.collider.bounds))
            {
                zones[o].ActivateEnemies();
                break;
            }

        }
	}
	
	// Update is called once per frame
	void Update () {
        //Screen.lockCursor = true;
        if (!winSprite.enabled)
        {
            levelTime += Time.deltaTime;
            timeText.text = "Level time: " + levelTime.ToString("f2") + " sec";
        }

        if (Input.GetKeyDown(KeyCode.Insert))
        {
            Application.LoadLevel(Application.loadedLevel);
        }
	}

    public void GameOver()
    {
        gameOverSprite.enabled = true;
        timeText.enabled = false;
    }

    public void Win()
    {
        winSprite.enabled = true;
    }
}
