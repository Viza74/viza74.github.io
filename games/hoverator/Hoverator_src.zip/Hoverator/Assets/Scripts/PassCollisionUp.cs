﻿using UnityEngine;
using System.Collections;

public class PassCollisionUp : MonoBehaviour {

	void OnCollisionEnter(Collision coll)
    {
        transform.parent.gameObject.SendMessage("OnCollisionEnter", coll);
    }
}
