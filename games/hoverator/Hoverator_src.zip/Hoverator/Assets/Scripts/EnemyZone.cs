﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EnemyZone : MonoBehaviour {

    public GameObject[] bridges;
    public List<GameObject> enemies;
    public AudioClip zoneClearSound;

	// Use this for initialization
	void Start () {
        for (int i = 0; i < bridges.Length; i++)
        {
            bridges[i].SetActive(false);
        }

        for (int i = 0; i < enemies.Count; i++)
        {
            enemies[i].SetActive(false);
        }
	}
	
    public void ActivateEnemies()
    {
        for (int i = 0; i < enemies.Count; i++)
        {
            enemies[i].SetActive(true);
        }
    }

	// Update is called once per frame
	void Update () {
	
	}

    public void Remove(GameObject enemy)
    {
        enemies.Remove(enemy);
        if (enemies.Count==0)
        {
            //Game.instance
            for (int i = 0; i < bridges.Length; i++)
            {
                bridges[i].SetActive(true);
                AudioSource.PlayClipAtPoint(zoneClearSound, Camera.main.transform.position);
            }
        }
    }

}
