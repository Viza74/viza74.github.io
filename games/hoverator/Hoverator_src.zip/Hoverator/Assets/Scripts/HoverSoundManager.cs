﻿using UnityEngine;
using System.Collections;

public class HoverSoundManager : MonoBehaviour {

    public AudioClip hoverStart;
    public AudioClip hoverLoop;

	// Use this for initialization
	void Start () {
        audio.clip = hoverStart;
        audio.loop = false;
        audio.Play();
        Invoke("PlayLoop", hoverStart.length);
	}
	
    void PlayLoop()
    {
        audio.clip = hoverLoop;
        audio.loop = true;
        audio.Play();
    }

    void Update()
    {
        RaycastHit hit;

        if (Physics.Raycast(transform.position, Vector3.up * -1, out hit, 5f))
        {
            audio.volume = 1 - (hit.distance / 5f);
        }
        else
        {
            audio.volume *= 0.98f;
        }
    }

}
