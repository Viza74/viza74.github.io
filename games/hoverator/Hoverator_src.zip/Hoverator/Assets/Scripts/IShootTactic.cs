﻿
public interface IShootTactic {

    // Should return the time to the next shoot
    float Fire();

}
