﻿using UnityEngine;
using System.Collections;

public class PlayerGun : MonoBehaviour {

    public GameObject bulletPrefab;
    public Transform gunpoint;
    public AudioClip shootSound;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Fire1"))
        {
            (Instantiate(bulletPrefab, gunpoint.position, gunpoint.rotation) as GameObject).transform.parent = Game.instance.entityParent;
            AudioSource.PlayClipAtPoint(shootSound, Camera.main.transform.position);
        }
	}
}
