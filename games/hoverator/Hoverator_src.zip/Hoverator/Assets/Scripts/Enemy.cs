﻿using UnityEngine;
using System.Collections;

public enum AimMode
{
    SetDirection,
    RandomDirection,
    AimAtPlayer
}

public enum MoveType
{
    Guard,
    Wanderer,
    Patrol,
    Hunter
}

public class Enemy : MonoBehaviour {

    public int life = 10;
    public GameObject explosion;
    

    [Space(20)]
    // Variables for moving
    public MoveType moveType;
    [Range(0f,360f)]
    public float startDir = 0;
    public float speed = 3f;
    public float turnInterval = 2f;
    float currDir = 0;
    float nextTurn = 0;
    [HideInInspector]
    public EnemyZone myZone;

    [Space(20)]
    // Variables for Aim()
    public AimMode aimMode = AimMode.RandomDirection;
    [Range(0f, 360f)]
    public float aimAngle = 0;
    public bool allowBlindShoot = false;
    Vector3 shootDir;
    
    // Variables for Fire()
    [Space(20)]
    public GameObject bulletPrefab;
    public int numBulletsToFire = 1;
    [Range(0f, 360f)]
    public float spread = 0;
    public bool randomSpread = false;

    bool canFire = true;
    [Space(10)]
    [Range(0f, 360f)]
    public float sequenceSpread = 0;
    [Range(-1f, 10f)]
    public float[] shootTiming;

    int currShootTimeIdx = 0;
    float nextFire = 0;

    [HideInInspector]
    public Bounds myBounds;
    Collider myCollider;

    void Awake()
    {
        myCollider = GetComponentInChildren<Collider>();
        myBounds = myCollider.bounds;
    }

	// Use this for initialization
	void Start () {
        currDir = startDir;

        
	}
	
	// Update is called once per frame
	void Update () {
        nextTurn -= Time.deltaTime;
        if (nextTurn<=0)
        {
            Turn();
        }

        
        Move();
        

        if (ShouldTryToFire())
        {
            if (TakeAim())
            {
                Fire();
            }
        }
	}

    void Move()
    {
        //transform.Translate(0, 0, speed * Time.deltaTime);
        transform.Translate(0, 0, speed * Time.deltaTime);
        myBounds = myCollider.bounds;

        if (!myZone.collider.bounds.Contains(myBounds.min) || !myZone.collider.bounds.Contains(myBounds.max))
        //if (!myZone.collider.bounds.Contains(collider.bounds.min) || !myZone.collider.bounds.Contains(collider.bounds.max))
        {
            transform.Translate(0, 0, -speed * Time.deltaTime);
            myBounds = myCollider.bounds;
            Turn();
        }
        
    }

    void Turn()
    {
        switch (moveType)
        {
            case MoveType.Guard:
                speed = 0;
                break;
            case MoveType.Wanderer:
                currDir = Random.Range(0f, 360f);
                break;
            case MoveType.Patrol:
                currDir += 180f;
                currDir = currDir % 360f;
                break;
            case MoveType.Hunter:
                if (Game.instance.player==null)
                {
                    return;
                }
                Vector3 playerDir = Game.instance.player.position-transform.position;
                playerDir.y = 0;
                Quaternion qq = Quaternion.LookRotation(-playerDir);
                currDir = qq.eulerAngles.y+180;
                break;
            default:
                break;
        }

        transform.rotation = Quaternion.Euler(0, currDir, 0);
        nextTurn = turnInterval<0?Random.Range(0.1f,3f):turnInterval;
    }

    bool ShouldTryToFire()
    {
        if (canFire)
        {
            nextFire -= Time.deltaTime;
            if (nextFire <= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;
    }

    bool TakeAim()
    {
        switch (aimMode)
        {
            case AimMode.SetDirection:
                shootDir = Quaternion.Euler(0, aimAngle, 0) * Vector3.forward;;
                return true;
            case AimMode.RandomDirection:
                shootDir = Quaternion.Euler(0, Random.Range(0,360), 0) * Vector3.forward;
                return true;
            case AimMode.AimAtPlayer:
                RaycastHit hit;
                shootDir = Game.instance.player.position - transform.position;

                if (Physics.Raycast(transform.position, shootDir, out hit, 100f))
                {
                    if (!allowBlindShoot && hit.collider.tag != "Player")
                    {
                        return false;
                    }
                    else
                    {
                        // A b.spped a bullet sebessége lenne az előre célzáshoz, de most így itt nincs ilyen...
                        //shootDir = (Game.instance.player.position + (Game.instance.player.forward * (hit.distance / b.speed))) - transform.position;
                        shootDir = (Game.instance.player.position + (Game.instance.player.forward * (hit.distance / 10f))) - transform.position;

                        return true;
                    }
                }
                break;
            default:
                break;
        }
        

        return false;
    }

    void Fire()
    {
        for (int i = 0; i < numBulletsToFire; i++)
        {
            Bullet b = (Instantiate(bulletPrefab) as GameObject).GetComponent<Bullet>();
            b.transform.parent = Game.instance.entityParent;
            b.transform.position = myCollider.transform.position;
            Quaternion bulletDir = Quaternion.LookRotation(shootDir);
            if (randomSpread)
            {
                bulletDir *= Quaternion.Euler(0, Random.Range(-spread/2f, spread/2f), 0);
            }
            else {
                bulletDir *= Quaternion.Euler(0, (currShootTimeIdx - shootTiming.Length / 2) * sequenceSpread / shootTiming.Length, 0);
                bulletDir *= Quaternion.Euler(0, (i - numBulletsToFire / 2) * spread / numBulletsToFire, 0);
            }
            
            b.transform.rotation = bulletDir;
        }

        nextFire = shootTiming[currShootTimeIdx]>=0?shootTiming[currShootTimeIdx]:Random.Range(0.03f,0.8f);
        currShootTimeIdx++;
        if (currShootTimeIdx>=shootTiming.Length)
        {
            currShootTimeIdx = 0;
        }
    }

    void OnCollisionEnter(Collision coll)
    {
        Bullet b = coll.transform.GetComponent<Bullet>();
        if (b!=null)
        {
            life -= b.damage;
            if (life <=0)
            {
                StartCoroutine(Utils.CameraShake(0.5f, 1.5f));
                GameObject psys = (Instantiate(explosion, myCollider.transform.position, Quaternion.identity) as GameObject);
                psys.transform.parent = Game.instance.entityParent;
                Destroy(psys, 1);

                myZone.Remove(gameObject);

                Destroy(gameObject);    
            }
        }
    }
}
