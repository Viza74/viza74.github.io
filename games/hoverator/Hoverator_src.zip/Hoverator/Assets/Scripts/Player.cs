﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    public int life = 30;
    int maxLife;
    public GameObject explosion;

    float nextCollDamage;
    float timeBetweenCollDamage = 0.4f;

    public Transform healthBar;
    float healthBarOrigScaleX;
    Vector3 healthBarScale;

	// Use this for initialization
	void Start () {
        healthBarScale = healthBar.localScale;
        healthBarOrigScaleX = healthBarScale.x;
        maxLife = life;
	}
	
	// Update is called once per frame
	void Update () {
        if (transform.position.y < -70)
        {
            life = 0;
        }

        healthBarScale.x = ((float)life / (float)maxLife) * healthBarOrigScaleX;
        healthBar.localScale = healthBarScale;

        if (life <= 0)
        {
            Game.instance.GameOver();

            GameObject psys = (Instantiate(explosion, transform.position, Quaternion.identity) as GameObject);
            psys.transform.parent = Game.instance.entityParent;
            Destroy(psys, 1);

            Destroy(gameObject);
        }
	}

    void OnCollisionEnter(Collision coll)
    {
        Bullet b = coll.transform.GetComponent<Bullet>();
        if (b != null)
        {
            life -= b.damage;
            StartCoroutine(Utils.CameraShake(0.5f, 1.5f));
        }

        if (coll.transform.gameObject.layer==LayerMask.NameToLayer("Enemies"))
        {
            life -= 1;
            nextCollDamage = timeBetweenCollDamage;
            StartCoroutine(Utils.CameraShake(0.5f,0.5f));
        }

       

    }

    void OnCollisionStay(Collision coll)
    {
        if (coll.transform.gameObject.layer == LayerMask.NameToLayer("Enemies"))
        {
            nextCollDamage -= Time.deltaTime;
            if (nextCollDamage <= 0)
            {
                life -= 1;
                StartCoroutine(Utils.CameraShake(0.3f, 0.5f));
            }
        }
    }
    
}
