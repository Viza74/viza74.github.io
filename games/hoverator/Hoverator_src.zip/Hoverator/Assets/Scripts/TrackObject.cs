﻿using UnityEngine;
using System.Collections;

public class TrackObject : MonoBehaviour {

    public Transform target;
    public float distanceUp;
    public float distanceBack;
    public float lookForward;
    public float minimumHeight;

    Vector3 positionVelocity;

    /*
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    */

    void FixedUpdate()
    {
        if (target==null)
        {
            return;
        }
        Vector3 newPosition = target.position + (target.forward*-distanceBack);
        newPosition.y = Mathf.Max(newPosition.y + distanceUp, minimumHeight);

        transform.position = Vector3.SmoothDamp(transform.position, newPosition, ref positionVelocity, 0.18f );

        Vector3 focalPoint = target.position + (target.forward*lookForward);
        transform.LookAt(focalPoint);
    }
}
