﻿using UnityEngine;
using System.Collections;

public class ZoneActivator : MonoBehaviour
{

    public EnemyZone[] targetZones;

    void OnTriggerEnter()
    {
        for (int i = 0; i < targetZones.Length; i++)
        {
            targetZones[i].ActivateEnemies();
        }

        gameObject.SetActive(false);
    }
}
