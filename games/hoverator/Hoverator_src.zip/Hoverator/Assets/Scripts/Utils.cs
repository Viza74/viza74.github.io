using UnityEngine;
using System.Collections;

public class Utils {

	public static void drawDebugPoint(Vector3 point, float size = 0.05F) {
		drawDebugPoint(point, Color.white, size);
	}
	
	public static void drawDebugPoint(Vector3 point, Color color, float size = 0.05F) {
		Vector3 vs = new Vector3();
		Vector3 ve = new Vector3();
		
		vs.x = point.x-size; vs.y = point.y; vs.z = point.z;
		ve.x = point.x+size; ve.y = point.y; ve.z = point.z;
		Debug.DrawLine(vs, ve, color);

		vs.x = point.x; vs.y = point.y-size; vs.z = point.z;
		ve.x = point.x; ve.y = point.y+size; ve.z = point.z;
		Debug.DrawLine(vs, ve, color);

		vs.x = point.x; vs.y = point.y; vs.z = point.z-size;
		ve.x = point.x; ve.y = point.y; ve.z = point.z+size;
		Debug.DrawLine(vs, ve, color);
		
	}

    static bool shakeInProgress = false;
	public static IEnumerator CameraShake (float duration, float magnitude)
	{
        if (Utils.shakeInProgress)
        {
            yield return null;
        }
		float elapsed = 0.0f;
		Vector3 originalCamPos = Camera.main.transform.position;
		while (elapsed < duration) {
			elapsed += Time.deltaTime;
			float percentComplete = elapsed / duration;
			float damper = 1.0f - Mathf.Clamp (4.0f * percentComplete - 3.0f, 0.0f, 1.0f);
// map noise to [-1, 1]
			float x = Mathf.PerlinNoise(Time.time * 10, 0) * 2.0f - 1.0f;
//			float x = Random.value * 2.0f - 1.0f;
            float y = Mathf.PerlinNoise(Time.time * 10, 5) * 2.0f - 1.0f;
//			float y = Random.value * 2.0f - 1.0f;
			x *= magnitude * damper;
			y *= magnitude * damper;
            Camera.main.transform.position = new Vector3(originalCamPos.x + x, originalCamPos.y+y, originalCamPos.z);
			yield return null;
		}
		Camera.main.transform.position = originalCamPos;
	}

    public static float getAngle(float x, float y)
    {
        float angle = Mathf.Atan(y / x);
        angle -= Mathf.PI / 2;
        if (x < 0)
        {
            angle += Mathf.PI;
        }
        if (x >= 0 && y < 0)
        {
            angle += 2 * Mathf.PI;
        }
        return angle;
    }

    /// <summary>
    /// Determine the signed angle between two vectors, with normal 'n'
    /// as the rotation axis.
    /// </summary>
    public static float AngleSigned(Vector3 v1, Vector3 v2, Vector3 n)
    {
        return Mathf.Atan2(
            Vector3.Dot(n, Vector3.Cross(v1, v2)),
            Vector3.Dot(v1, v2)) * Mathf.Rad2Deg;
    }

    private static float d;
    private static Plane plane = new Plane(Vector3.up, Vector3.zero);
    private static Ray ray;

    public static Vector3 getPointOnPlane(Vector3 screenPos)
    {
        ray = Camera.main.ScreenPointToRay(screenPos);
        if (plane.Raycast(ray, out d))
        {
            return ray.GetPoint(d);
        }
        return Vector3.zero;
    }

    public static Bounds GetBoundsFor(Component[] objects, bool useColliders = true)
    {

        Bounds ret = useColliders ? objects[0].collider.bounds : objects[0].renderer.bounds;
        for (int i = 1; i < objects.Length; i++)
        {
            ret.Encapsulate(useColliders ? objects[i].collider.bounds : objects[i].renderer.bounds);
        }
        return ret;
    }
}
