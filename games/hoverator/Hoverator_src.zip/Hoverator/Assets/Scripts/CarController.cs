﻿using UnityEngine;
using System.Collections;

public class CarController : MonoBehaviour {

    public float acceleration;
    public float rotationRate;

    public float turnRotationAngle;
    public float turnRotationSeekSpeed;

    float rotationVelocity;
    float groundAngleVelocity;


    /*
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    */

    void FixedUpdate()
    {
        if (Game.instance.winSprite.enabled)
        {
            rigidbody.drag = 10;
            return;
        }

        if (Physics.Raycast(transform.position, transform.up*-1, 3f))
        {
            rigidbody.drag = 1;

            Vector3 forwardForce = transform.forward * acceleration * Input.GetAxis("Vertical");
            forwardForce *= Time.deltaTime * rigidbody.mass;

            rigidbody.AddForce(forwardForce);
        }
        else
        {
            rigidbody.drag = 0;
        }

        Vector3 turnTorque = Vector3.up * rotationRate * Input.GetAxis("Horizontal");
        //Vector3 turnTorque = Vector3.up * rotationRate * Input.GetAxis("Mouse X");
        turnTorque *= Time.deltaTime * rigidbody.mass;
        rigidbody.AddTorque(turnTorque);

        Vector3 newRotation = transform.eulerAngles;
        //newRotation.z = Mathf.SmoothDampAngle(newRotation.z, Input.GetAxis("Mouse X") * -turnRotationAngle, ref rotationVelocity, turnRotationSeekSpeed);
        newRotation.z = Mathf.SmoothDampAngle(newRotation.z, Input.GetAxis("Horizontal") * -turnRotationAngle, ref rotationVelocity, turnRotationSeekSpeed);
        transform.eulerAngles = newRotation;

        

    }
}
